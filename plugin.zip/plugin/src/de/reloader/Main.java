package de.reloader;

import cn.nukkit.plugin.PluginBase;
import cn.nukkit.plugin.Plugin;
import cn.nukkit.command.Command;
import cn.nukkit.command.CommandSender;
import cn.nukkit.utils.Config;
import java.io.File;
import java.util.List;
import java.util.ArrayList;

public class Main extends PluginBase {

    private Config blacklistConfig;

    @Override
    public void onEnable() {
        if (!this.getDataFolder().exists()) {
            this.getDataFolder().mkdirs();
        }
        File file = new File(this.getDataFolder(), "blacklist.yml");
        if (!file.exists()) {
            this.saveResource("blacklist.yml");
        }
        this.blacklistConfig = new Config(file, Config.YAML);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("reloadplugins") && sender.isOp()) {
            
            this.blacklistConfig.reload();
            List<String> blacklist = new ArrayList<>(this.blacklistConfig.getStringList("plugins"));
            String lang = this.getServer().getLanguage().getLang().toLowerCase();
            
            String msgStart = "§eStarting reload...";
            String msgSkip = "§7Skipping: ";
            String msgReload = "§bReloading: ";
            String msgDone = "§aFinished!";
            String msgError = "§cError in %s! Auto-blacklisted.";

            switch (lang) {
                case "deu":
                case "de":
                    msgStart = "§eStarte Reload..."; msgSkip = "§7Überspringe: "; msgReload = "§bLade neu: "; msgDone = "§aAbgeschlossen!"; msgError = "§cFehler in %s! Automatisch blacklisted.";
                    break;
                case "chs":
                    msgStart = "§e开始重载..."; msgSkip = "§7跳过: "; msgReload = "§b正在重载: "; msgDone = "§a完成！"; msgError = "§c%s 发生错误！已自动加入黑名单。";
                    break;
                case "cht":
                    msgStart = "§e開始重載..."; msgSkip = "§7跳過: "; msgReload = "§b正在重載: "; msgDone = "§a完成！"; msgError = "§c%s 發生錯誤！已自動加入黑名單。";
                    break;
                case "rus":
                    msgStart = "§eЗапуск перезагрузки..."; msgSkip = "§7Пропуск: "; msgReload = "§bПерезагрузка: "; msgDone = "§aГотово!"; msgError = "§cОшибка в %s! Автоматически в черном списке.";
                    break;
                case "spa":
                    msgStart = "§eIniciando recarga..."; msgSkip = "§7Omitiendo: "; msgReload = "§bRecargando: "; msgDone = "§a¡Finalizado!"; msgError = "§c¡Error en %s! Añadido a la lista negra.";
                    break;
                case "fra":
                    msgStart = "§eDémarrage du rechargement..."; msgSkip = "§7Ignoré: "; msgReload = "§bRechargement: "; msgDone = "§aTerminé !"; msgError = "§cErreur dans %s ! Ajouté à la liste noire.";
                    break;
                case "jpn":
                    msgStart = "§eリロードを開始します..."; msgSkip = "§7スキップ: "; msgReload = "§bリロード中: "; msgDone = "§a完了！"; msgError = "§c%sでエラーが発生しました！ブラックリストに追加されました。";
                    break;
                case "kor":
                    msgStart = "§e리로드 시작 중..."; msgSkip = "§7건너뛰기: "; msgReload = "§b리로드 중: "; msgDone = "§a완료!"; msgError = "§c%s에 오류가 발생했습니다! 블랙리스트에 추가되었습니다.";
                    break;
                case "pol":
                    msgStart = "§eRozpoczynanie ponownego ładowania..."; msgSkip = "§7Pomijanie: "; msgReload = "§bPonowne ładowanie: "; msgDone = "§aZakończono!"; msgError = "§cBłąd w %s! Dodano do czarnej listy.";
                    break;
                case "tur":
                    msgStart = "§eYeniden yükleme başlatılıyor..."; msgSkip = "§7Atlanıyor: "; msgReload = "§bYeniden yükleniyor: "; msgDone = "§aTamamlandı!"; msgError = "§c%s eklentisinde hata! Kara listeye eklendi.";
                    break;
                case "ukr":
                    msgStart = "§eЗапуск перезавантаження..."; msgSkip = "§7Пропуск: "; msgReload = "§bПерезавантаження: "; msgDone = "§aГотово!"; msgError = "§cПомилка в %s! Автоматично в чорному списку.";
                    break;
                case "bra":
                    msgStart = "§eIniciando recarga..."; msgSkip = "§7Ignorando: "; msgReload = "§bRecarregando: "; msgDone = "§aConcluído!"; msgError = "§cErro em %s! Adicionado à lista negra.";
                    break;
                case "cze":
                    msgStart = "§eSpouštění znovunačtení..."; msgSkip = "§7Přeskakování: "; msgReload = "§bZnovunačítání: "; msgDone = "§aDokončeno!"; msgError = "§cChyba v %s! Přidáno na černou listinu.";
                    break;
                case "idn":
                    msgStart = "§eMemulai memuat ulang..."; msgSkip = "§7Melewati: "; msgReload = "§bMemuat ulang: "; msgDone = "§aSelesai!"; msgError = "§cKesalahan pada %s! Masuk daftar hitam otomatis.";
                    break;
            }

            sender.sendMessage(msgStart);

            for (Plugin plugin : this.getServer().getPluginManager().getPlugins().values()) {
                String name = plugin.getName();

                if (blacklist.contains(name) || name.equalsIgnoreCase("Reloader")) {
                    sender.sendMessage(msgSkip + name);
                    continue;
                }

                try {
                    sender.sendMessage(msgReload + name);
                    this.getServer().getPluginManager().disablePlugin(plugin);
                    this.getServer().getPluginManager().enablePlugin(plugin);
                } catch (Throwable t) {

                    sender.sendMessage(String.format(msgError, name));
                    if (!blacklist.contains(name)) {
                        blacklist.add(name);
                        this.blacklistConfig.set("plugins", blacklist);
                        this.blacklistConfig.save();
                    }
                }
            }

            sender.sendMessage(msgDone);
            return true;
        }
        return false;
    }
}
