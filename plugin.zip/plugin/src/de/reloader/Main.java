package de.reloader;

import cn.nukkit.plugin.PluginBase;
import cn.nukkit.command.Command;
import cn.nukkit.command.CommandSender;

public class Main extends PluginBase {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
if (cmd.getName().equalsIgnoreCase("reloadplugins") && sender.isOp()) {
    sender.sendMessage("§eReload wird gestartet...");
    this.getServer().getPluginManager().disablePlugins(); this.getServer().getPluginManager().loadPlugins(this.getServer().getPluginPath());
    for (cn.nukkit.plugin.Plugin plugin : this.getServer().getPluginManager().getPlugins().values()) {
        this.getServer().getPluginManager().enablePlugin(plugin);
    }
    
    sender.sendMessage("§aPlugins wurden erfolgreich reaktiviert!");
    return true;
}
        return false;
    }
}
